# NBTA: The Notebook Teaching Assistant

nbta (the "Notebook Teaching Assistant") is a Python package that I developped to help me teach and grade data science and machine learning classes.

## Formative Feedback

The formative feedback module is where all of the code to return user friendly tests in notebooks resides. The goal of the formative feedback module is to help student learn to identify their mistakes based on comprehensive tests. The tests are meant to be verbose in order to point out where the mistake lies.

## Sumative Feedback

The summative feedback module is where all the code to mark assessements resides. Sumative is intended to use Python tests to autograde or manually grade notebooks.

## Notebooks

The notebook module contains all the code needed to manipulate notebooks. This can be used directly, or is implicetely used when using the summative module


